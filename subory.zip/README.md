<h1 align="left">🚀Domáci bezpečnostný systém:</h1>

###

<p align="left">Stránka githubu určená pre ročníkový projekt na tému domáci bezpečnostný systém.</p>

###

<h2 align="left">💎Vychytávky:</h2>

###

<p align="left">✅Pohybový senzor<br>✅Detekcia otvorených dverí/okien<br>✅Zvukový alarm<br>✅Webové rozhranie</p>

###

<h2 align="left">💻Vytvorené v:</h2>

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/arduino/arduino-original.svg" height="40" alt="arduino logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" height="40" alt="css3 logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" height="40" alt="html5 logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="40" alt="javascript logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" height="40" alt="mysql logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" height="40" alt="php logo"  />
</div>
